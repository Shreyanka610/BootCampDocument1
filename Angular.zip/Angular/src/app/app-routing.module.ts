import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { VieworderComponent } from './vieworder/vieworder.component';
import { AddorderComponent } from './addorder/addorder.component';
import { HomeComponent } from './home/home.component';

const routes: Routes = [
  {path:'',redirectTo:'home',pathMatch:'full'},
  {path:'viewOrder',component:VieworderComponent},
  {path:'addOrder',component:AddorderComponent},
  {path:'home',component:HomeComponent},
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
