import { Component, OnInit } from '@angular/core';
import { Order } from '../order';
import { OrderService } from '../order.service';

@Component({
  selector: 'app-addorder',
  templateUrl: './addorder.component.html',
  styleUrls: ['./addorder.component.css']
})
export class AddorderComponent implements OnInit {
  order:Order=new Order();
  msg:string;
  errormsg:string;
  constructor(private orderservice:OrderService) { }
  ngOnInit(): void {
  }

  addOrder(){
    this.orderservice.addOrder(this.order).subscribe((data)=>{
      console.log("data",data);
      this.msg=data;
      this.errormsg=undefined;
      this.order=new Order()},
      error=>{alert("Invalid Details");});
      
    }
  }

