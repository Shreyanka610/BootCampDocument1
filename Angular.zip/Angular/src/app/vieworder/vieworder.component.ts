import { Component, OnInit } from '@angular/core';
import { Order } from '../order';
import { OrderService } from '../order.service';

@Component({
  selector: 'app-vieworder',
  templateUrl: './vieworder.component.html',
  styleUrls: ['./vieworder.component.css']
})
export class VieworderComponent implements OnInit {
  order:Order;
  orderId:number;
  constructor(private orderservice:OrderService) { }
  ngOnInit(): void {
     
  }
  viewOrder(){
    console.log(this.orderId);
    this.orderservice.viewOrder(this.orderId).subscribe((data)=>{
      data = JSON.parse(data);
      if(data !=null){
        this.order=data as Order;
        console.log(this.order.orderId);
      }
      else{
        alert("ID is not present");
      }
    });
  }

}



