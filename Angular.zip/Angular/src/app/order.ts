export class Order {
    orderId:number;
    book:string;
    author:string;
    price:number;
    quantity:number;
    subTotal:number;
}