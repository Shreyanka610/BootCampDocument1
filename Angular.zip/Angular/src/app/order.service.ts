import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Order } from './order';

@Injectable({
  providedIn: 'root'
})
export class OrderService {

  constructor(private http:HttpClient) { }


  public addOrder(order:Order):Observable<any>{
    return this.http.post("http://localhost:6588/addOrder",order,{responseType:'text'});
  }
  public viewOrder(orderId:number):Observable<any>{
    return this.http.get(`http://localhost:6588/viewOrder/${orderId}`,{responseType:'text'});
  }  
}
