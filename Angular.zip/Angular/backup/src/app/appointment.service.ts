import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http'
import { Observable } from 'rxjs';
import { Appointment } from './appointment';
@Injectable({
  
  providedIn: 'root'
})
export class AppointmentService {

  constructor(private http:HttpClient) { }
  viewAppointments():Observable<any>{
  return this.http.get("http://localhost:6588/viewAppointments");
}
public makeAppointment(newAppointment:NewAppointment):Observable<any>{
  return this.http.post("http://localhost:6585/makeAppointment",newAppointment,{responseType:'text'});
}
getCenters():Observable<any> {
  return this.http.get("http://localhost:6585/centers");
}

getTests():Observable<any> {
  return this.http.get("http://localhost:6585/tests");
}
approveAppointments(appId: number):Observable<any> {
  return this.http.put("http://localhost:6585/approve",appId,{responseType:'text'});
}

}

}
