import { Component, OnInit } from '@angular/core';
import { AppointmentService } from '../appointment.service';
import { Appointment } from '../appointment';

@Component({
  selector: 'app-view',
  templateUrl: './view.component.html',
  styleUrls: ['./view.component.css']
})
export class ViewComponent implements OnInit {
appointments:Appointment[]=[];
  constructor(private appointmentService:AppointmentService) {}

  ngOnInit(){
    this.appointmentService.viewAppointments().subscribe(data=>this.appointments=data);
  }
}

