package com.capgemini.bookstore.service;

import com.capgemini.bookstore.entity.Order;

import java.util.List;

public interface OrderService {

		boolean AddOrder(Order order);

	    List<Order> showallorder();

}