package com.capgemini.bookstore;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ShreyuBooKStoreApplication {

	public static void main(String[] args) {
		SpringApplication.run(ShreyuBooKStoreApplication.class, args);
	}

}
