import { Component, OnInit } from '@angular/core';
import { Order } from '../order';
import { OrderService } from '../order.service';

@Component({
  selector: 'app-addorder',
  templateUrl: './addorder.component.html',
  styleUrls: ['./addorder.component.css']
})
export class AddorderComponent implements OnInit {
  order:Order=new Order();
  msg:String;
  errorMsg:String;

  constructor(private orderService:OrderService) { }

  ngOnInit(): void {
  }
  addorder(){
    console.log("Inside AddOrder");
    this.orderService.AddOrder(this.order).subscribe((data)=>{
      console.log("data",data);
      this.msg=data;
      this.order=new Order()},
      error=>{this.errorMsg=JSON.parse(error.error).message;
        console.log(error.error);
        this.msg=undefined});

    }

  }