import { Component, OnInit } from '@angular/core';
import { OrderService } from '../order.service';
import { Order } from '../order';

@Component({
  selector: 'app-myorder',
  templateUrl: './myorder.component.html',
  styleUrls: ['./myorder.component.css']
})
export class MyorderComponent implements OnInit {
  orders:Order[]=[];
  constructor(private orderService:OrderService) { }

  ngOnInit(): void {
    console.log("Am inside show order");
    this.orderService.vieworder().subscribe(data=>this.orders=data);
    console.log(this.orders);
  }

}