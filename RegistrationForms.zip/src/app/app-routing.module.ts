import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import {AddorderComponent} from './addorder/addorder.component'
import { MyorderComponent } from './myorder/myorder.component';

const routes: Routes = [
   {path:'addorder', component:AddorderComponent},
  {path:'myorder', component:MyorderComponent},
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
