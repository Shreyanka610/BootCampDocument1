import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-approve',
  templateUrl: './approve.component.html',
  styleUrls: ['./approve.component.css']
})
export class ApproveComponent implements OnInit {

  appointments:Appointment[]=[];
  msg:string;
  errorMsg:string;
  constructor(private appointmentService:AppointmentService) {}

  ngOnInit(){
    this.appointmentService.viewAppointments().subscribe(data=>this.appointments=data);
  }
  approve(appId:number){
    console.log("Approve id:"+appId);
    this.appointmentService.approveAppointments(appId)
    .subscribe(
      (data)=>{this.msg=data},
      (error)=>{this.errorMsg=error.error}
      );
      //Reload the Appointements
      this.appointmentService.viewAppointments().subscribe(data=>this.appointments=data);
  }
}
