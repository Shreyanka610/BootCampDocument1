import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Routes, RouterModule } from '@angular/router';

import { ViewComponent } from './view/view.component';
import { MakeAppointmentComponent } from './make-appointment/make-appointment.component';
import { ApproveComponent } from './approve/approve.component';

const routes: Routes=[
    {path:'view' , component: ViewComponent},
    {path:'make-appointment', component:MakeAppointmentComponent},
    {path:'approve', component:ApproveComponent}
];


@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule{}

  