
export class NewAppointment 
{
    testId:number;
    userId:number;
    centerId:number;
    appointmentDate:Date;
 
}


export class Appointment 
{
    appointmentId:number;
    appointmentDate:Date;
    approved:boolean;
    center:Center;
    test:Test;
    users:Users;
}
export class Center{
    centerId:number;
    centerName:String;
}
export class Test
{
    testId:number;
    testName:String;   
}
export class Users{
    userId:number;
    userPassword:String;
    userName:String;
    contactNo:number;
    userRole:string;
    emailId:string;
}